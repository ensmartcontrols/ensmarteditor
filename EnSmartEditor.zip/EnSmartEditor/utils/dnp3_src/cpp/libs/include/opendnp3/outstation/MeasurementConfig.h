/*
 * Licensed to Green Energy Corp (www.greenenergycorp.com) under one or
 * more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Green Energy Corp licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the Infoific language governing permissions and
 * limitations under the License.
 *
 * This project was forked on 01/01/2013 by Automatak, LLC and modifications
 * may have been made to this file. Automatak, LLC licenses these modifications
 * to you under the terms of the License.
 */

#ifndef OPENDNP3_MEASUREMENTCONFIG_H
#define OPENDNP3_MEASUREMENTCONFIG_H

#include "opendnp3/app/MeasurementInfo.h"
#include "opendnp3/gen/PointClass.h"

namespace opendnp3
{

// All entries have this information
struct IndexConfig
{
	// virtual index for discontiguous data, as opposed to the raw array index
	uint16_t vIndex = 0;
};

// All entries have this information
template <class Info>
struct StaticConfig : IndexConfig
{
	typename Info::static_variation_t svariation = Info::DefaultStaticVariation;
};

template <class Info>
struct EventConfig : StaticConfig<Info>
{
	PointClass clazz = PointClass::Class1;
	typename Info::event_variation_t evariation = Info::DefaultEventVariation;
};

template <class Info>
struct DeadbandConfig : EventConfig<Info>
{
	typename Info::value_t deadband = 0;
};

class BinaryConfig : public EventConfig<BinaryInfo> {};
class DoubleBitBinaryConfig : public EventConfig<DoubleBitBinaryInfo> {};
class AnalogConfig : public DeadbandConfig<AnalogInfo> {};
class CounterConfig : public DeadbandConfig<CounterInfo> {};
class FrozenCounterConfig : public DeadbandConfig<FrozenCounterInfo> {};
class BOStatusConfig : public EventConfig<BinaryOutputStatusInfo> {};
class AOStatusConfig : public DeadbandConfig<AnalogOutputStatusInfo> {};
class TimeAndIntervalConfig : public StaticConfig<TimeAndIntervalInfo> {};
class SecurityStatConfig : public IndexConfig {};

}

#endif
